DROP TABLE IF EXISTS `#__quickform` ;
DROP TABLE IF EXISTS `#__quickform_ps` ;
