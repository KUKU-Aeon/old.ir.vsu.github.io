if (typeof TimelineLite == 'undefined') {
    alert('GSAP - TimelineLite missing');
}

window.NextendTimeline = TimelineLite;

if (typeof TweenLite == 'undefined') {
    alert('GSAP - TweenLite missing');
}
window.NextendTween = TweenLite;


if (typeof SplitText == 'undefined') {
    alert('GSAP - SplitText missing');
}
window.NextendSplitText = SplitText;