<?php
/**
 * @author Joomla! Extensions Store
 * @package RESPONSIVIZER::ROUTER::plugins::system
 * @copyright (C)2015 - Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html
 */
defined('_JEXEC') or die('Restricted access');
define('ROUTER_MODE_SKIP_SEF', 2);
define('ROUTER_MODE_SKIP_RAW', -1);
jimport('joomla.plugin.plugin');

/**
 * Observer class notified on events
 * 
 * @author Joomla! Extensions Store
 * @package RESPONSIVIZER::ROUTER::plugins::system
 * @since 2.0
 */
class plgSystemRouterReplacer extends JPlugin {
	/**
	 * Manage custom redirects for desktop->mobile links to menu
	 *
	 * @access private
	 * @return void
	 */
	private function customRedirectsRoute () {
		// DB connector
		$db = JFactory::getDbo();
		$app = JFactory::getApplication();
		
		// Load all custom redirects
		$query = $db->getQuery(true);
		$query->select($db->qn('itemid_source'));
		$query->select($db->qn('itemid_target'));
		$query->from($db->qn('#__rvzr_redirects'));
		$query->where($db->qn('published') . '= 1');
		$activeRedirects = $db->setQuery($query)->loadObjectList();
		
		
		// Found some custom redirects active, now search for a match
		if(count($activeRedirects)) {
			$menu = $app->getMenu();
			$activeMenu = $menu->getActive();
			$currentItemid = $activeMenu->id;
			
			// Get the router
			$router = $app->getRouter();
			
			//Avoid risk of recursion on multiple parse on same request
			$clonedRouter = clone($router);
			
			foreach ($activeRedirects as $activeRedirect) {
				// Check for a match
				if($currentItemid != $activeRedirect->itemid_source) {
					continue;
				}
				
				// Get the menu item to switch to as the set home for mobile devices from settings
				$switchToItemid = $activeRedirect->itemid_target;
				if(!$switchToItemid) {
					continue;
				}
				$switchToMenu = $menu->getItem($switchToItemid);
				
				// Parse new JUri route
				$newUriInstance = JUri::getInstance(JUri::base() . $switchToMenu->route);
				$result = $clonedRouter->parse($newUriInstance);
				
				// Overwrite REQUEST vars in current application dispatch, notice: skipped entirely when language filter plugin is active and do redirect
				if(is_array($result) && count($result)) {
					foreach ($result as $getVarName=>$getVarValue) {
						$app->input->set($getVarName, $getVarValue);
					}
				}
			}
		}
	}
	
	/**
	 * Manage after routing event
	 *
	 * @access public
	 * @return boolean
	 */
	public function onAfterRoute() {
		$app = JFactory::getApplication();
		$document = JFactory::getDocument();
		$template = $app->getTemplate();
		if ($document->getType() !== 'html' || $app->input->get('tmpl') === 'component' || $template !== $this->params->get('template')) {
			return false;
		}

		if ($app->input->get("task") == "edit" || $app->isAdmin() || $app->input->get("option") == 'com_users' || $app->input->get("option") == 'com_search') {
			return false;
		}
		
		// Detect the home menu itemid in standard mode - keep multilanguage multimenu home id
		$menu = $app->getMenu();
		$activeMenu = $menu->getActive();
		if(!is_object($activeMenu)) {
			return false;
		}
		
		$currentItemid = $activeMenu->id;
		$isHome = (bool)$activeMenu->home;

		// If home route detected get the custom mobile and overwite router parse and set request vars
		if($isHome && $this->params->get('mobile_homepage_menuid') && $this->params->get('mobile_homepage')) {
			// Get the router
			$router = $app->getRouter();
				
			//Avoid risk of recursion on multiple parse on same request
			$clonedRouter = clone($router);
				
			// Get the menu item to switch to as the set home for mobile devices from settings
			$switchToItemid = $this->params->get('mobile_homepage_menuid');
			if(!$switchToItemid) {
				return false;
			}
			$switchToMenu = $menu->getItem($switchToItemid);
				
			// Parse new JUri route
			$newUriInstance = JUri::getInstance(JUri::base() . $switchToMenu->route);
			$result = $clonedRouter->parse($newUriInstance);
				
			// Overwrite REQUEST vars in current application dispatch
			if(is_array($result) && count($result)) {
				foreach ($result as $getVarName=>$getVarValue) {
					$app->input->set($getVarName, $getVarValue);
				}
			}
		} else {
			// Check if some custom redirects are set and enabled
			if($this->params->get('redirects_enable', 0)) {
				$this->customRedirectsRoute();
			}
		}
	}

	public function __construct(&$subject) {
		parent::__construct($subject);
		$this->params = JComponentHelper::getParams('com_responsivizer');
	}
}
