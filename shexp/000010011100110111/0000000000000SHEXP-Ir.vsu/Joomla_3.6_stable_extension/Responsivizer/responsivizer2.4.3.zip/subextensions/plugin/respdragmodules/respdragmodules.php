<?php
/**
 * @package RESPONSIVIZER::plugins::system
 * @subpackage responsivizer
 * @author Joomla! Extensions Store
 * @copyright (C)2015 Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html
 */
defined ( '_JEXEC' ) or die ();

jimport ( 'joomla.plugin.plugin' );
jimport ( 'joomla.application.component.helper' );

/**
 * Main plugin for Visual Studio tasks, it renders the sidebar app widget,
 * and most important it renders the template positions layout for interactions
 *
 * @package RESPONSIVIZER::plugins::system
 * @subpackage responsivizer
 * @since 1.0
 */
class PlgSystemRespdragmodules extends JPlugin {
	/**
	 * App reference
	 *
	 * @access protected
	 * @var Object
	 */
	protected $app;
	
	/**
	 * Document reference
	 *
	 * @access protected
	 * @var Object
	 */
	protected $doc;
	
	/**
	 * Component params global object
	 *
	 * @access protected
	 * @var Object
	 */
	protected $cParams;
	
	private function addView() {
		$base = JUri::root ();
		$app = JFactory::getApplication();
		
		// Stylesheets
		$this->doc->addStyleSheet ( JUri::root(true) . '/administrator/components/com_responsivizer/assets/css/modules.css' );
		
		// JS Frameworks
		if($this->cParams->get('load_own_mootools', 0)) {
			$this->doc->addScript ( JUri::root(true) . '/administrator/components/com_responsivizer/js/mootools-core.js' );
			$this->doc->addScript ( JUri::root(true) . '/administrator/components/com_responsivizer/js/mootools-more.js' );
		}
		
		JHtml::_ ( 'behavior.framework', true );
		JHtml::_ ( 'behavior.modal' );
		
		// App scripts
		$this->doc->addScript ( JUri::root(true) . '/administrator/components/com_responsivizer/js/modules.js', 'text/javascript', true );
		
		// Config js vars
		$this->doc->addScriptDeclaration('var rsAddToTop=' . $this->cParams->get('add_top_stack', 0) . ';');
	}
	
	/**
	 * This is where all the magic happens, the module positions are rendered for interactions through code wrapping,
	 * every scripts from the main view are injected in the document using the view constructor
	 *
	 * @access private
	 * @return void
	 */
	private function renderAppLayout($dropable_js_var) {
		// Check if the plugin can get executed
		if ($this->app->input->getInt ( 'rsenable', 0 ) == 1) {
			// Ensure that a JDocumentHTML request has been dispatched
			if (strtolower(get_class ( $this->doc )) != strtolower('JDocumentHTML')) {
				return false;
			}
			
			// Check if module wrapping is valid, no visual styles editing must be enabled
			$templateTags = $this->getPositions ( $this->doc->template );
			
			// Apply magic, wrap and set in the document elements the modified modules layout for dashboard user interactions
			foreach ( $templateTags as $position => $style ) {
				// Clean cache
				JFactory::getCache ()->clean ( 'com_modules', '' );
				
				// Retrieve all modules
				$modules = JModuleHelper::getModules ( $position );
				$showModuleName = $this->cParams->get ( 'show_module_name', 0 );
				$showModuleTitle = $this->cParams->get ( 'show_module_title', 0 );
				$renderModules = $this->cParams->get ( 'render_modules', 1 );
				
				// Start wrap layout
				$content = '<div class="rs-wrapper"><div class="rs-position-name"><span class="rs-label-badge-primary">' . $position . '</span></div><div id="sort-' . $position . '">';
				foreach ( $modules as $module ) {
					// Choose to show/hide module name
					$edit_link = null;
					$module->showtitle = $showModuleTitle;
					
					// Is it a valid module
					if ($module->id > 0) {
						$move_icon = '<span class="fa fa-arrows rs_move_icon" title="Drag and drop"></span>';
						
						$content .= '<div id="' . $module->id . '" class="rs-title">';
						$content .= '<span class="rs-label-badge-warning">' . $module->title . '</span>';
						if ($showModuleName) {
							$content .= '<span class="rs-label-badge-default">' . $module->module . '</span>';
						}
						$content .= ' ' . $move_icon;
						
						// Choose to show/hide module contents
						if ($renderModules) {
							$content .= '<div class="module_rendered_contents">' . JModuleHelper::renderModule ( $module, array (
									'style' => ($style ? $style : 'responsivizer')
							) ) . '</div>';
						}
						$content .= '</div>';
					}
				}
				$content .= '</div></div>';
				
				// Set the buffer in the document for the rendered interactive module
				$this->doc->setBuffer ( $content, "modules", $position );
			}
			
			
			// Add view scripts and resources
			$this->addView();
			
			// Choose to show/hide the main component output
			$showComponent = $this->cParams->get ( 'show_component', 1 );
			if (! $showComponent) {
				$this->doc->setBuffer ( "", "component" );
			} else {
				if ($this->app->input->getInt ( 'visualstyles', 0 ) != 1) {
					$componentBuffer = $this->doc->getBuffer ( 'component' );
					$componentBuffer = '<div class="rs-component-name"><span class="rs-label-badge-primary">Main component area</span>' . $componentBuffer . '</div>';
					$this->doc->setBuffer ( $componentBuffer, "component" );
				}
			}
		}
	}
	
	/**
	 * Parse a template manifest to find positions supported
	 *
	 * @access private
	 * @return array
	 */
	private function getPositions($template) {
		$templateDetails = JPATH_THEMES . '/' . $template . '/templateDetails.xml';
		$path = JPath::clean ( $templateDetails );
		$items = array ();
		if (file_exists ( $path ) && ($xml = simplexml_load_file ( $path )) && isset ( $xml->positions [0] )) {
			foreach ( $xml->positions [0] as $position ) {
				$items [( string ) $position] = null;
			}
		}
		return $items;
	}
	
	/**
	 * Application event
	 *
	 * @access public
	 */
	public function onBeforeRender() {
		$this->app = JFactory::getApplication ();
		$this->doc = JFactory::getDocument ();
		
		// Validate side execution
		if ($this->app->isAdmin ()) {
			return false;
		}
		
		if($this->doc->getType() !== 'html' || $this->app->input->getCmd ( 'tmpl' ) === 'component') {
			return false;
		}
		
		if (!$this->app->input->get('rsenable', 0)) {
			return false;
		}
		
		$jConfig = JFactory::getConfig();
		$token = md5($jConfig->get('secret') . date('Y-m-d') . 'com_responsivizer');
		if ($this->app->input->get('token', null) != $token) {
			return false;
		}
		
		// Force templating positions on
		// Get component config params
		$this->cParams = JComponentHelper::getParams ( 'com_responsivizer' );
		JComponentHelper::getParams ( 'com_templates' )->set ( 'template_positions_display', 1 );
		
		$this->renderAppLayout ( 'rs-position-name' );
	}
}