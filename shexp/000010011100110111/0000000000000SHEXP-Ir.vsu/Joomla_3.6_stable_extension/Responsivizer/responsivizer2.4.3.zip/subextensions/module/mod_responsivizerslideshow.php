<?php
/**
 * @author Joomla! Extensions Store
 * @package RESPONSIVIZER::MODULESLIDESHOW::modules::mod_responsivizerslideshow
 * @copyright (C)2015 - Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html
 */
defined('_JEXEC') or die;

$doc = JFactory::getDocument();
$cParams = JComponentHelper::getParams('com_responsivizer');
require_once(dirname(__FILE__) . '/helper.php');
$module_id = $module->id;
$moduleclass_sfx = htmlspecialchars($cParams->get('moduleclass_sfx'));
$listofimages = modResponsivizerHelper::getImages($cParams);
$listofFolderImages = modResponsivizerHelper::getFolderImages($params);
modResponsivizerHelper::load_jquery($cParams);
$doc->addStyleSheet(JUri::base(true) . '/modules/mod_responsivizerslideshow/assets/css/responsivizer.css', 'text/css');
$doc->addScript(JUri::base(true) . '/modules/mod_responsivizerslideshow/assets/js/jquery.responsivizer.js');

// Set parameters
$slide_theme = $cParams->get('slide_theme', 'false');
$enable_minheight = $cParams->get('enable_minheight');
$min_height = $cParams->get('min_height');
$bg_color = $cParams->get('bg_color', '#ffffff');
$theme_shadow = $cParams->get('theme_shadow', 'theme-shadow-normal');
$theme_border = $cParams->get('theme_border', '00');
$theme_border_radius = $cParams->get('theme_border_radius', '00');
$transition = $cParams->get('transition', 'fade');
$easing = $cParams->get('easing', 'easeInQuart');
$direction = $cParams->get('direction', 'horizontal');
$animSpeed = intval($cParams->get('animSpeed', '2000'));
$pauseTime = intval($cParams->get('pauseTime', '3500'));
$controlNav = $cParams->get('controlNav', 'true');
$positionNav = $cParams->get('positionNav', 'under');
$colorNav = $cParams->get('colorNav', 'dark');
$colorNavActive = $cParams->get('colorNavActive', 'black');
$directionNav = $cParams->get('directionNav', 'default');
$pauseOnHover = $cParams->get('pauseOnHover', 'true');
$initDelay = $cParams->get('initDelay', '0');
$randomize = $cParams->get('randomize', 'false');
$bg_caption = $cParams->get('bg_caption', 'black');
$transparency_caption = $cParams->get('transparency_caption', '2');
$position_caption = $cParams->get('position_caption', 'bottom');
$text_align = $cParams->get('text_align', 'centered');
$color_caption = $cParams->get('color_caption', '#dddddd');
$imagesAutoHeight = $cParams->get('images_auto_height', 'true');

require(JModuleHelper::getLayoutPath('mod_responsivizerslideshow'));
