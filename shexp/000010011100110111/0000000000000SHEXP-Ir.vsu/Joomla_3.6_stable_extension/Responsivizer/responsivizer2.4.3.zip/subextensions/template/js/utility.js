//'use strict';

/* Modernizr 2.7.0 (Custom Build) | MIT & BSD
 * Build: http://modernizr.com/download/#-applicationcache-canvas-canvastext-draganddrop-hashchange-history-audio-video-indexeddb-input-inputtypes-localstorage-postmessage-sessionstorage-websockets-websqldatabase-webworkers-shiv-testprop-testallprops-hasevent-domprefixes-load
 */
;window.Modernizr=function(a,b,c){function y(a){i.cssText=a}function z(a,b){return y(prefixes.join(a+";")+(b||""))}function A(a,b){return typeof a===b}function B(a,b){return!!~(""+a).indexOf(b)}function C(a,b){for(var d in a){var e=a[d];if(!B(e,"-")&&i[e]!==c)return b=="pfx"?e:!0}return!1}function D(a,b,d){for(var e in a){var f=b[a[e]];if(f!==c)return d===!1?a[e]:A(f,"function")?f.bind(d||b):f}return!1}function E(a,b,c){var d=a.charAt(0).toUpperCase()+a.slice(1),e=(a+" "+n.join(d+" ")+d).split(" ");return A(b,"string")||A(b,"undefined")?C(e,b):(e=(a+" "+o.join(d+" ")+d).split(" "),D(e,b,c))}function F(){e.input=function(c){for(var d=0,e=c.length;d<e;d++)r[c[d]]=c[d]in j;return r.list&&(r.list=!!b.createElement("datalist")&&!!a.HTMLDataListElement),r}("autocomplete autofocus list placeholder max min multiple pattern required step".split(" ")),e.inputtypes=function(a){for(var d=0,e,g,h,i=a.length;d<i;d++)j.setAttribute("type",g=a[d]),e=j.type!=="text",e&&(j.value=k,j.style.cssText="position:absolute;visibility:hidden;",/^range$/.test(g)&&j.style.WebkitAppearance!==c?(f.appendChild(j),h=b.defaultView,e=h.getComputedStyle&&h.getComputedStyle(j,null).WebkitAppearance!=="textfield"&&j.offsetHeight!==0,f.removeChild(j)):/^(search|tel)$/.test(g)||(/^(url|email)$/.test(g)?e=j.checkValidity&&j.checkValidity()===!1:e=j.value!=k)),q[a[d]]=!!e;return q}("search tel url email datetime date month week time datetime-local number range color".split(" "))}var d="2.7.0",e={},f=b.documentElement,g="modernizr",h=b.createElement(g),i=h.style,j=b.createElement("input"),k=":)",l={}.toString,m="Webkit Moz O ms",n=m.split(" "),o=m.toLowerCase().split(" "),p={},q={},r={},s=[],t=s.slice,u,v=function(){function d(d,e){e=e||b.createElement(a[d]||"div"),d="on"+d;var f=d in e;return f||(e.setAttribute||(e=b.createElement("div")),e.setAttribute&&e.removeAttribute&&(e.setAttribute(d,""),f=A(e[d],"function"),A(e[d],"undefined")||(e[d]=c),e.removeAttribute(d))),e=null,f}var a={select:"input",change:"input",submit:"form",reset:"form",error:"img",load:"img",abort:"img"};return d}(),w={}.hasOwnProperty,x;!A(w,"undefined")&&!A(w.call,"undefined")?x=function(a,b){return w.call(a,b)}:x=function(a,b){return b in a&&A(a.constructor.prototype[b],"undefined")},Function.prototype.bind||(Function.prototype.bind=function(b){var c=this;if(typeof c!="function")throw new TypeError;var d=t.call(arguments,1),e=function(){if(this instanceof e){var a=function(){};a.prototype=c.prototype;var f=new a,g=c.apply(f,d.concat(t.call(arguments)));return Object(g)===g?g:f}return c.apply(b,d.concat(t.call(arguments)))};return e}),p.canvas=function(){var a=b.createElement("canvas");return!!a.getContext&&!!a.getContext("2d")},p.canvastext=function(){return!!e.canvas&&!!A(b.createElement("canvas").getContext("2d").fillText,"function")},p.postmessage=function(){return!!a.postMessage},p.websqldatabase=function(){return!!a.openDatabase},p.indexedDB=function(){return!!E("indexedDB",a)},p.hashchange=function(){return v("hashchange",a)&&(b.documentMode===c||b.documentMode>7)},p.history=function(){return!!a.history&&!!history.pushState},p.draganddrop=function(){var a=b.createElement("div");return"draggable"in a||"ondragstart"in a&&"ondrop"in a},p.websockets=function(){return"WebSocket"in a||"MozWebSocket"in a},p.video=function(){var a=b.createElement("video"),c=!1;try{if(c=!!a.canPlayType)c=new Boolean(c),c.ogg=a.canPlayType('video/ogg; codecs="theora"').replace(/^no$/,""),c.h264=a.canPlayType('video/mp4; codecs="avc1.42E01E"').replace(/^no$/,""),c.webm=a.canPlayType('video/webm; codecs="vp8, vorbis"').replace(/^no$/,"")}catch(d){}return c},p.audio=function(){var a=b.createElement("audio"),c=!1;try{if(c=!!a.canPlayType)c=new Boolean(c),c.ogg=a.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),c.mp3=a.canPlayType("audio/mpeg;").replace(/^no$/,""),c.wav=a.canPlayType('audio/wav; codecs="1"').replace(/^no$/,""),c.m4a=(a.canPlayType("audio/x-m4a;")||a.canPlayType("audio/aac;")).replace(/^no$/,"")}catch(d){}return c},p.localstorage=function(){try{return localStorage.setItem(g,g),localStorage.removeItem(g),!0}catch(a){return!1}},p.sessionstorage=function(){try{return sessionStorage.setItem(g,g),sessionStorage.removeItem(g),!0}catch(a){return!1}},p.webworkers=function(){return!!a.Worker},p.applicationcache=function(){return!!a.applicationCache};for(var G in p)x(p,G)&&(u=G.toLowerCase(),e[u]=p[G](),s.push((e[u]?"":"no-")+u));return e.input||F(),e.addTest=function(a,b){if(typeof a=="object")for(var d in a)x(a,d)&&e.addTest(d,a[d]);else{a=a.toLowerCase();if(e[a]!==c)return e;b=typeof b=="function"?b():b,typeof enableClasses!="undefined"&&enableClasses&&(f.className+=" "+(b?"":"no-")+a),e[a]=b}return e},y(""),h=j=null,function(a,b){function l(a,b){var c=a.createElement("p"),d=a.getElementsByTagName("head")[0]||a.documentElement;return c.innerHTML="x<style>"+b+"</style>",d.insertBefore(c.lastChild,d.firstChild)}function m(){var a=s.elements;return typeof a=="string"?a.split(" "):a}function n(a){var b=j[a[h]];return b||(b={},i++,a[h]=i,j[i]=b),b}function o(a,c,d){c||(c=b);if(k)return c.createElement(a);d||(d=n(c));var g;return d.cache[a]?g=d.cache[a].cloneNode():f.test(a)?g=(d.cache[a]=d.createElem(a)).cloneNode():g=d.createElem(a),g.canHaveChildren&&!e.test(a)&&!g.tagUrn?d.frag.appendChild(g):g}function p(a,c){a||(a=b);if(k)return a.createDocumentFragment();c=c||n(a);var d=c.frag.cloneNode(),e=0,f=m(),g=f.length;for(;e<g;e++)d.createElement(f[e]);return d}function q(a,b){b.cache||(b.cache={},b.createElem=a.createElement,b.createFrag=a.createDocumentFragment,b.frag=b.createFrag()),a.createElement=function(c){return s.shivMethods?o(c,a,b):b.createElem(c)},a.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+m().join().replace(/[\w\-]+/g,function(a){return b.createElem(a),b.frag.createElement(a),'c("'+a+'")'})+");return n}")(s,b.frag)}function r(a){a||(a=b);var c=n(a);return s.shivCSS&&!g&&!c.hasCSS&&(c.hasCSS=!!l(a,"article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}template{display:none}")),k||q(a,c),a}var c="3.7.0",d=a.html5||{},e=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,f=/^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,g,h="_html5shiv",i=0,j={},k;(function(){try{var a=b.createElement("a");a.innerHTML="<xyz></xyz>",g="hidden"in a,k=a.childNodes.length==1||function(){b.createElement("a");var a=b.createDocumentFragment();return typeof a.cloneNode=="undefined"||typeof a.createDocumentFragment=="undefined"||typeof a.createElement=="undefined"}()}catch(c){g=!0,k=!0}})();var s={elements:d.elements||"abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",version:c,shivCSS:d.shivCSS!==!1,supportsUnknownElements:k,shivMethods:d.shivMethods!==!1,type:"default",shivDocument:r,createElement:o,createDocumentFragment:p};a.html5=s,r(b)}(this,b),e._version=d,e._domPrefixes=o,e._cssomPrefixes=n,e.hasEvent=v,e.testProp=function(a){return C([a])},e.testAllProps=E,e}(this,this.document),function(a,b,c){function d(a){return"[object Function]"==o.call(a)}function e(a){return"string"==typeof a}function f(){}function g(a){return!a||"loaded"==a||"complete"==a||"uninitialized"==a}function h(){var a=p.shift();q=1,a?a.t?m(function(){("c"==a.t?B.injectCss:B.injectJs)(a.s,0,a.a,a.x,a.e,1)},0):(a(),h()):q=0}function i(a,c,d,e,f,i,j){function k(b){if(!o&&g(l.readyState)&&(u.r=o=1,!q&&h(),l.onload=l.onreadystatechange=null,b)){"img"!=a&&m(function(){t.removeChild(l)},50);for(var d in y[c])y[c].hasOwnProperty(d)&&y[c][d].onload()}}var j=j||B.errorTimeout,l=b.createElement(a),o=0,r=0,u={t:d,s:c,e:f,a:i,x:j};1===y[c]&&(r=1,y[c]=[]),"object"==a?l.data=c:(l.src=c,l.type=a),l.width=l.height="0",l.onerror=l.onload=l.onreadystatechange=function(){k.call(this,r)},p.splice(e,0,u),"img"!=a&&(r||2===y[c]?(t.insertBefore(l,s?null:n),m(k,j)):y[c].push(l))}function j(a,b,c,d,f){return q=0,b=b||"j",e(a)?i("c"==b?v:u,a,b,this.i++,c,d,f):(p.splice(this.i++,0,a),1==p.length&&h()),this}function k(){var a=B;return a.loader={load:j,i:0},a}var l=b.documentElement,m=a.setTimeout,n=b.getElementsByTagName("script")[0],o={}.toString,p=[],q=0,r="MozAppearance"in l.style,s=r&&!!b.createRange().compareNode,t=s?l:n.parentNode,l=a.opera&&"[object Opera]"==o.call(a.opera),l=!!b.attachEvent&&!l,u=r?"object":l?"script":"img",v=l?"script":u,w=Array.isArray||function(a){return"[object Array]"==o.call(a)},x=[],y={},z={timeout:function(a,b){return b.length&&(a.timeout=b[0]),a}},A,B;B=function(a){function b(a){var a=a.split("!"),b=x.length,c=a.pop(),d=a.length,c={url:c,origUrl:c,prefixes:a},e,f,g;for(f=0;f<d;f++)g=a[f].split("="),(e=z[g.shift()])&&(c=e(c,g));for(f=0;f<b;f++)c=x[f](c);return c}function g(a,e,f,g,h){var i=b(a),j=i.autoCallback;i.url.split(".").pop().split("?").shift(),i.bypass||(e&&(e=d(e)?e:e[a]||e[g]||e[a.split("/").pop().split("?")[0]]),i.instead?i.instead(a,e,f,g,h):(y[i.url]?i.noexec=!0:y[i.url]=1,f.load(i.url,i.forceCSS||!i.forceJS&&"css"==i.url.split(".").pop().split("?").shift()?"c":c,i.noexec,i.attrs,i.timeout),(d(e)||d(j))&&f.load(function(){k(),e&&e(i.origUrl,h,g),j&&j(i.origUrl,h,g),y[i.url]=2})))}function h(a,b){function c(a,c){if(a){if(e(a))c||(j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}),g(a,j,b,0,h);else if(Object(a)===a)for(n in m=function(){var b=0,c;for(c in a)a.hasOwnProperty(c)&&b++;return b}(),a)a.hasOwnProperty(n)&&(!c&&!--m&&(d(j)?j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}:j[n]=function(a){return function(){var b=[].slice.call(arguments);a&&a.apply(this,b),l()}}(k[n])),g(a[n],j,b,n,h))}else!c&&l()}var h=!!a.test,i=a.load||a.both,j=a.callback||f,k=j,l=a.complete||f,m,n;c(h?a.yep:a.nope,!!i),i&&c(i)}var i,j,l=this.yepnope.loader;if(e(a))g(a,0,l,0);else if(w(a))for(i=0;i<a.length;i++)j=a[i],e(j)?g(j,0,l,0):w(j)?B(j):Object(j)===j&&h(j,l);else Object(a)===a&&h(a,l)},B.addPrefix=function(a,b){z[a]=b},B.addFilter=function(a){x.push(a)},B.errorTimeout=1e4,null==b.readyState&&b.addEventListener&&(b.readyState="loading",b.addEventListener("DOMContentLoaded",A=function(){b.removeEventListener("DOMContentLoaded",A,0),b.readyState="complete"},0)),a.yepnope=k(),a.yepnope.executeStack=h,a.yepnope.injectJs=function(a,c,d,e,i,j){var k=b.createElement("script"),l,o,e=e||B.errorTimeout;k.src=a;for(o in d)k.setAttribute(o,d[o]);c=j?h:c||f,k.onreadystatechange=k.onload=function(){!l&&g(k.readyState)&&(l=1,c(),k.onload=k.onreadystatechange=null)},m(function(){l||(l=1,c(1))},e),i?k.onload():n.parentNode.insertBefore(k,n)},a.yepnope.injectCss=function(a,c,d,e,g,i){var e=b.createElement("link"),j,c=i?h:c||f;e.href=a,e.rel="stylesheet",e.type="text/css";for(j in d)e.setAttribute(j,d[j]);g||(n.parentNode.insertBefore(e,n),m(c,0))}}(this,document),Modernizr.load=function(){yepnope.apply(window,[].slice.call(arguments,0))};
/*! Respond.js v1.4.0: min/max-width media query polyfill * Copyright 2013 Scott Jehl*/
!function(a){a.matchMedia=a.matchMedia||function(a){var b,c=a.documentElement,d=c.firstElementChild||c.firstChild,e=a.createElement("body"),f=a.createElement("div");return f.id="mq-test-1",f.style.cssText="position:absolute;top:-100em",e.style.background="none",e.appendChild(f),function(a){return f.innerHTML='&shy;<style media="'+a+'"> #mq-test-1 { width: 42px; }</style>',c.insertBefore(e,d),b=42===f.offsetWidth,c.removeChild(e),{matches:b,media:a}}}(a.document)}(this),function(a){"use strict";function b(){u(!0)}var c={};a.respond=c,c.update=function(){};var d=[],e=function(){var b=!1;try{b=new a.XMLHttpRequest}catch(c){b=new a.ActiveXObject("Microsoft.XMLHTTP")}return function(){return b}}(),f=function(a,b){var c=e();c&&(c.open("GET",a,!0),c.onreadystatechange=function(){4!==c.readyState||200!==c.status&&304!==c.status||b(c.responseText)},4!==c.readyState&&c.send(null))};if(c.ajax=f,c.queue=d,c.regex={media:/@media[^\{]+\{([^\{\}]*\{[^\}\{]*\})+/gi,keyframes:/@.*keyframes[^\{]+\{(?:[^\{\}]*\{[^\}\{]*\})+[^\}]+\}/gi,urls:/(url\()['"]?([^\/\)'"][^:\)'"]+)['"]?(\))/g,findStyles:/@media *([^\{]+)\{([\S\s]+?)$/,only:/(only\s+)?([a-zA-Z]+)\s?/,minw:/\([\s]*min\-width\s*:[\s]*([\s]*[0-9\.]+)(px|em)[\s]*\)/,maxw:/\([\s]*max\-width\s*:[\s]*([\s]*[0-9\.]+)(px|em)[\s]*\)/},c.mediaQueriesSupported=a.matchMedia&&null!==a.matchMedia("only all")&&a.matchMedia("only all").matches,!c.mediaQueriesSupported){var g,h,i,j=a.document,k=j.documentElement,l=[],m=[],n=[],o={},p=30,q=j.getElementsByTagName("head")[0]||k,r=j.getElementsByTagName("base")[0],s=q.getElementsByTagName("link"),t=function(){var a,b=j.createElement("div"),c=j.body,d=k.style.fontSize,e=c&&c.style.fontSize,f=!1;return b.style.cssText="position:absolute;font-size:1em;width:1em",c||(c=f=j.createElement("body"),c.style.background="none"),k.style.fontSize="100%",c.style.fontSize="100%",c.appendChild(b),k.insertBefore(c,k.firstChild),a=b.offsetWidth,f?k.removeChild(c):c.removeChild(b),k.style.fontSize=d,e&&(c.style.fontSize=e),a=i=parseFloat(a)},u=function(b){var c="clientWidth",d=k[c],e="CSS1Compat"===j.compatMode&&d||j.body[c]||d,f={},o=s[s.length-1],r=(new Date).getTime();if(b&&g&&p>r-g)return a.clearTimeout(h),h=a.setTimeout(u,p),void 0;g=r;for(var v in l)if(l.hasOwnProperty(v)){var w=l[v],x=w.minw,y=w.maxw,z=null===x,A=null===y,B="em";x&&(x=parseFloat(x)*(x.indexOf(B)>-1?i||t():1)),y&&(y=parseFloat(y)*(y.indexOf(B)>-1?i||t():1)),w.hasquery&&(z&&A||!(z||e>=x)||!(A||y>=e))||(f[w.media]||(f[w.media]=[]),f[w.media].push(m[w.rules]))}for(var C in n)n.hasOwnProperty(C)&&n[C]&&n[C].parentNode===q&&q.removeChild(n[C]);for(var D in f)if(f.hasOwnProperty(D)){var E=j.createElement("style"),F=f[D].join("\n");E.type="text/css",E.media=D,q.insertBefore(E,o.nextSibling),E.styleSheet?E.styleSheet.cssText=F:E.appendChild(j.createTextNode(F)),n.push(E)}},v=function(a,b,d){var e=a.replace(c.regex.keyframes,"").match(c.regex.media),f=e&&e.length||0;b=b.substring(0,b.lastIndexOf("/"));var g=function(a){return a.replace(c.regex.urls,"$1"+b+"$2$3")},h=!f&&d;b.length&&(b+="/"),h&&(f=1);for(var i=0;f>i;i++){var j,k,n,o;h?(j=d,m.push(g(a))):(j=e[i].match(c.regex.findStyles)&&RegExp.$1,m.push(RegExp.$2&&g(RegExp.$2))),n=j.split(","),o=n.length;for(var p=0;o>p;p++)k=n[p],l.push({media:k.split("(")[0].match(c.regex.only)&&RegExp.$2||"all",rules:m.length-1,hasquery:k.indexOf("(")>-1,minw:k.match(c.regex.minw)&&parseFloat(RegExp.$1)+(RegExp.$2||""),maxw:k.match(c.regex.maxw)&&parseFloat(RegExp.$1)+(RegExp.$2||"")})}u()},w=function(){if(d.length){var b=d.shift();f(b.href,function(c){v(c,b.href,b.media),o[b.href]=!0,a.setTimeout(function(){w()},0)})}},x=function(){for(var b=0;b<s.length;b++){var c=s[b],e=c.href,f=c.media,g=c.rel&&"stylesheet"===c.rel.toLowerCase();e&&g&&!o[e]&&(c.styleSheet&&c.styleSheet.rawCssText?(v(c.styleSheet.rawCssText,e,f),o[e]=!0):(!/^([a-zA-Z:]*\/\/)/.test(e)&&!r||e.replace(RegExp.$1,"").split("/")[0]===a.location.host)&&("//"===e.substring(0,2)&&(e=a.location.protocol+e),d.push({href:e,media:f})))}w()};x(),c.update=x,c.getEmValue=t,a.addEventListener?a.addEventListener("resize",b,!1):a.attachEvent&&a.attachEvent("onresize",b)}}(this);
/* FitVids */
(function(e){e.fn.fitVids=function(t){var n={customSelector:null};if(!document.getElementById("fit-vids-style")){var r=document.createElement("div"),i=document.getElementsByTagName("base")[0]||document.getElementsByTagName("script")[0];r.className="fit-vids-style";r.id="fit-vids-style";r.style.display="none";r.innerHTML="<style>.fluid-width-video-wrapper{width: 100%;position: relative;padding: 0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed,.fluid-width-video-wrapper video {position: absolute;top: 0;left: 0;width: 100%;height: 100%;}</style>";i.parentNode.insertBefore(r,i)}if(t){e.extend(n,t)}return this.each(function(){var t=["iframe[src*='player.vimeo.com']","iframe[src*='youtube.com']","iframe[src*='youporn.com']","iframe[src*='spankwire.com']","iframe[src*='spankbang.com']","iframe[src*='youtube-nocookie.com']","iframe[src*='kickstarter.com'][src*='video.html']","object","embed","video"];if(n.customSelector){t.push(n.customSelector)}var r=e(this).find(t.join(","));r=r.not("object object");r.each(function(){var t=e(this);if(this.tagName.toLowerCase()==="embed"&&t.parent("object").length||t.parent(".fluid-width-video-wrapper").length){return}var n=this.tagName.toLowerCase()==="object"||t.attr("height")&&!isNaN(parseInt(t.attr("height"),10))?parseInt(t.attr("height"),10):t.height(),r=!isNaN(parseInt(t.attr("width"),10))?parseInt(t.attr("width"),10):t.width(),i=n/r;if(!t.attr("id")){var s="fitvid"+Math.floor(Math.random()*999999);t.attr("id",s)}t.wrap('<div class="fluid-width-video-wrapper"></div>').parent(".fluid-width-video-wrapper").css("padding-top",i*100+"%");t.removeAttr("height").removeAttr("width");if(this.tagName.toLowerCase()==="video"){t.attr("width","100%");if(e(this).attr('autoplay')){this.play()}}})})}})(jQuery);
/**
 * UTILITY frontend class
 * 
 * @package RESPONSIVIZER::templates::responsivizer
 * @subpackage js
 * @author Joomla! Extensions Store
 * @copyright (C)2013 Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html
 */
(function($) {
	var Utility = function() {
	/**
	 * Local reference to network status
	 * 
	 * @access private
	 * @var Boolean
	 */
	var networkStatus;
	
	/**
	 * Check network status and manage application cache forced refresh
	 * 
	 * @access public
	 * @return Boolean
	 */
	this.checkNetworkStatus = function() {
		// Only check status and optional refresh if application cache and local storage are supported
		if(!Modernizr.applicationcache || !Modernizr.localstorage || !rvzrOfflineCache) {
			return false;
		}
		
		// Try to detect if are online/offline through a more reliable async request
		$.ajax({
			type: 'POST',
			url: rvzrBaseURI + "index.php?option=com_responsivizer&task=dummycontroller.dummytask",
			async: true,
			success: function(data, textStatus, jqXHR){
				// Store existing status
				var previousStatus = localStorage.getItem('networkStatus');
				networkStatus = true;
				localStorage.setItem('networkStatus', networkStatus);
				// If we was offline it's the moment to force a refresh to get now fresh cache resources
				if(previousStatus === 'false') {
					// Browser downloaded a new app cache.
					window.location.reload();
				}
			},
			error: function(jqXHR, textStatus, error){
				networkStatus = false;
				localStorage.setItem('networkStatus', networkStatus);
			}
		}); 
	};
		
	/**
	 * Function dummy constructor
	 * 
	 * @access private
	 * @param String contextSelector
	 * @method <<IIFE>>
	 * @return Void
	 */
	  (function __construct() {
		// Microplugin extend
	    jQuery.fn.clickToggle = function(a,b) {
		  var ab=[b,a];
		  function cb(jqEvent){ ab[this._tog^=1].call(this); return false;}
		  return this.on("click", cb);
		};

		// Touch menu and submenu management
		try {
			var targetLI = $('ul.menu li.parent.deeper, ul.menu li.parent');
			var currentOpenParentmenus = new Array();
			$(targetLI).on('click', function(event) {
				if (!$(this).hasClass('clicked')) {
					if(currentOpenParentmenus.length && !$(this).parents('li.parent').hasClass('clicked')) {
						$.each(currentOpenParentmenus, function(index, elem){
							$(elem).removeClass('clicked');
						});
					}
					$(this).addClass('clicked');
					event.preventDefault();
					currentOpenParentmenus.push(this);
					return false;
				}
				if ("standalone" in window.navigator && window.navigator.standalone) { } else {
					event.stopPropagation();
				}
			});
			$('body').not('ul.menu').on('click', function() {
				$(targetLI).removeClass('clicked');
				currentOpenParentmenus = new Array();
			});
		} catch (e) {
		}
		  
		// Fitvids initialization
		$('div.site').fitVids();
		
		// FitImages/FitTables initialization
		$('*.' + rvzrResponsiveElementsClassname).css({'width':'100%', 'height':'auto'});
		if(rvzrResponsiveElementsSelectors) {
			$(rvzrResponsiveElementsSelectors).css({'width':'100%', 'height':'auto'});
		}
		
		// Responsive IFrames management
		if(rvzrResponsiveIFramesSelectors) {
			// Find all iframes
			var $iframes = $(rvzrResponsiveIFramesSelectors);
			 
			// Find and save the aspect ratio for all iframes
			$iframes.each(function () {
				// Remove the hardcoded width and height attributes
				$( this ).data( "ratio", this.height / this.width )
			    		 .removeAttr( "width" )
			    		 .removeAttr( "height" );
			});
			 
			// Resize the iframes when the window is resized
			$(window).on('resize', function (jqEvent, firstCall) {
			  $iframes.each( function() {
			    // Get the parent containers width
			    var width = $( this ).parent().width();
			    $( this ).width( width )
			      		 .height( width * $( this )
			      		 .data( "ratio" ) );
			  	});
			});
		}
		
		// Headers accordion instance
		if(rvzrAccordionStatus) {
			$('h3.module:not(.menumodule):not(.noaccordion)').addClass('activearrows');
			$('h3.menumodule:not(.noaccordion)').addClass('activeaccordion');
			$('h3.menumodule:not(.noaccordion), h3.module:not(.noaccordion)').css('cursor', 'pointer').click(function(event) {
				$(this).nextAll().slideToggle();
			});
			
			if(rvzrAccordionMenuCollapsed) {
				$('h3.menumodule:not(.menutop):not(.noaccordion)').nextAll().hide();
			}
			
			if(rvzrAccordionCollapsed) {
				$('h3.module:not(.menumodule):not(.noaccordion)').each(function(k, elem) {
					var h3Title = $(elem).text();
					if(h3Title) {
						$(elem).nextAll().hide();
					}
				});
			}
		} else {
			$('h3.menumodule').each(function(k, elem) {
				var h3Title = $(elem).text();
				if(!h3Title) {
					$(elem).addClass('empty');
				}
			});
			
			$('h3.menumodule.menutop').addClass('activeaccordion');
			$('h3.menumodule.menutop').css('cursor', 'pointer').click(function(event) {
				$(this).nextAll().slideToggle();
			});
		}

		// Manage collision between top and side menus
		$('h3.menumodule.menutop').clickToggle(function() {
			$('nav.side_menu').css({'z-index': 0});
			var triggerSideMenu = $("#sidemenu_trigger_container");
			if (triggerSideMenu.data("open")) {
				var slideMenu = $("#sidemenu_trigger_container").parent();
				$(slideMenu).css(animateMenuSideStartingPixelObject);
				triggerSideMenu.data("open", false).trigger('click');
			}
		}, function() {
			$('nav.side_menu').css({'z-index': 99999});
		});
		
		// Manage accordion for the top menu
		if(rvzrAccordionTopMenuCollapsed) {
			$('h3.menumodule.menutop').nextAll().hide();
			if(rvzrAccordionTopMenuCollapsedNoFouc) {
				$('nav.top_menu').css({'height':'auto', 'overflow':'visible'});
			}
		}
		
		// Optimize main content space based on next element
		var nextMainChilds = $('#main_component').next('.right-module-position').children().length;
		var mainComponentPadding = parseInt($('#main_component').css('padding-left'));
		if(!nextMainChilds && !mainComponentPadding) {
			$('#main_component').css({'width':'100%'});
		}
		
		// Manage application cache operation based on network status
		this.checkNetworkStatus();
		
		// Build the size of the side menu based on viewport width
		var viewportWidth = null;
		var maxMenuSize = null;
		var animateMenuSideZeroObject = {};
		var animateMenuSideStartingPixelObject = {};
		var animateMenuSideStartingScalarObject = {};
		animateMenuSideZeroObject[rvzrMenuSideLocation] = 0;
		
		$(window).on('resize', function(jqEvent, firstCall){
			viewportWidth = $(window).width();
			if(viewportWidth > 480) {
				viewportWidth = 480;
			}
			maxMenuSize = viewportWidth - 60;
			animateMenuSideStartingPixelObject[rvzrMenuSideLocation] = (-maxMenuSize) + 'px';
			animateMenuSideStartingScalarObject[rvzrMenuSideLocation] = -maxMenuSize;
			$('nav.side_menu').width(maxMenuSize);
			// Position menu on first call
			if(firstCall || !$("#sidemenu_trigger_container").data("open")) {
				$('nav.side_menu').css(animateMenuSideStartingPixelObject);
			}
		}).trigger('resize',[true]);
		
		// Toggle the side menu if any using the tab trigger and fill exactly the device browser viewport
		$('#sidemenu_trigger_container').clickToggle(function() {
			var slideMenu = $(this).parent();
			$(slideMenu).stop().animate(animateMenuSideZeroObject, 500);
			$(this).data("open", true)
		}, function() {
			// Check if it's a valid close operation, or already closed by top menu
			if($(this).data("open")) {
				var slideMenu = $(this).parent();
				$(slideMenu).stop().animate(animateMenuSideStartingScalarObject, 500);
				
				$(this).data("open", false);
			}
		});
		$(document).on("click touchstart", 'body > div.site', function(jqEvent) {
			// Test if valid element to trigger the event
			if(!$(jqEvent.target).hasClass('menuside') && 
			   !$(jqEvent.target).parents('div.menuside').length &&
			   !$(jqEvent.target).parents('nav.side_menu').length &&
			    $(jqEvent.target).data('role') != 'trigger') {
				if ($("#sidemenu_trigger_container").data("open")) {
					$("#sidemenu_trigger_container").trigger("click")
				}
			}
		});
		
		// Memoize the touch on search field to ensure keyboard opening
		$(document).on('click touchstart', '#mod-search-searchword', function(){
			$(this).focus();
		});
      }).call(this);
  }

  // On DOM Ready
  $(function () {
      window.ResponsivizerUtility = new Utility();
  });
})(jQuery);