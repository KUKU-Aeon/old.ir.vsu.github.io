/**
 * Reposition dashboard for drag and drop modules
 * 
 * @package RESPONSIVIZER::MODULESMANAGER::administrator::components::com_responsivizer
 * @subpackage js
 * @author Joomla! Extensions Store
 * @copyright (C) 2015 Joomla! Extensions Store
 * @license GNU/GPLv2 or later, see license.txt
 */
// 'use strict';
(function($) {
	var ModulesManagerDrag = function(ctrlsSelector) {
		/**
		 * Parse url to grab query string params to post to server side for sitemap generation
		 * 
		 * @access private
		 * @return Object
		 */
		var parseURL = function(url) {
		    var a =  document.createElement('a');
		    a.href = url;
		    return {
		        source: url,
		        protocol: a.protocol.replace(':',''),
		        host: a.hostname,
		        port: a.port,
		        query: a.search,
		        params: (function(){
		            var ret = {},
		                seg = a.search.replace(/^\?/,'').split('&'),
		                len = seg.length, i = 0, s;
		            for (;i<len;i++) {
		                if (!seg[i]) { continue; }
		                s = seg[i].split('=');
		                ret[s[0]] = s[1];
		            }
		            return ret;
		        })(),
		        file: (a.pathname.match(/\/([^\/?#]+)$/i) || [,''])[1],
		        hash: a.hash.replace('#',''),
		        path: a.pathname.replace(/^([^\/])/,'/$1'),
		        relative: (a.href.match(/tps?:\/\/[^\/]+(.+)/) || [,''])[1],
		        segments: a.pathname.replace(/^\//,'').split('/')
		    };
		}
		
		/**
		 * Add preview button to the toolbar based on a fancybox iframe solution
		 * 
		 * @access private
		 * @return Void
		 */
		var addPreviewButton = function() {
			var currentDashboardLocation = responsivizerBaseURI;
			/**
			 * Snippet to append for previer on template dashboard
			 */
			var previewBtnSnippet = '<div class="btn-wrapper" id="toolbar-preview">' + 
										'<a id="rs_preview_btn" href="' + responsivizerBaseURI + '" class="btn btn-small btn-success fancybox_iframe">' +
											'<span class="icon-out"></span> ' + COM_RESPONSIVIZER_PREVIEW + 
										'</a>' +
									'</div>';
			$('#toolbar').append(previewBtnSnippet);

			// Fancybox iframe for modules management dashboard
			if ($('a.fancybox_iframe').length) {
				$("a.fancybox_iframe").fancybox({
					type : 'iframe',
					autoSize : false,
					beforeLoad : function () {
						/**
						 * Get the current iframe dashboard location and use it to open the preview
						 */
						try {
							currentDashboardLocation = $('#rvzr_dragmodules').get(0).contentWindow.location.href;
							// Clean the parsed url
							var parsedURL = parseURL(currentDashboardLocation);
							var tempLocation = parsedURL.protocol + '://' + parsedURL.host + parsedURL.path;
							var urlParams = {};
							$.each(parsedURL.params, function (urlParam, urlValue){
								if($.inArray(urlParam, ['token', 'rsenable']) == -1) {
									urlParams[urlParam] = urlValue;
								}
							});
							if(!$.isEmptyObject(urlParams)) {
								var chainCharacter = '?';
								$.each(urlParams, function(urlParam, urlValue){
									tempLocation += chainCharacter + urlParam + '=' + urlValue;
									chainCharacter = '&';
								});
							}
							currentDashboardLocation = tempLocation;
							$('#rs_preview_btn').attr('href', currentDashboardLocation);
						} catch(e) {}
					},
					afterLoad : function(upcoming) {
						// Add custom width/height class
						$('div.fancybox-wrap').addClass('fancybox-wrap-preview');
						$('div.fancybox-inner').addClass('fancybox-inner-preview');
						
						$($('iframe[id^=fancybox]')).attr('scrolling', 'yes');
						$($('iframe[id^=fancybox]')).attr('src', currentDashboardLocation);
					}
				});
			}
		};

		/**
		 * Add lightbox button to access native modules management
		 * 
		 * @access private
		 * @return Void
		 */
		var addMMButton = function() {
			// Append switch to default modules manager button link
			$('#toolbar').append('<a href="index.php?option=com_modules" class="fancybox_iframe_mm fancybox btn btn-primary btn-xs absolute hidden-phone">' + 
								 	'<span class="icon-out-2"></span> ' + COM_RESPONSIVIZER_SWITCH_TO_JOOMLA_MM + 
								 '</a>');

			// Fancybox iframe for native modules management
			if ($('a.fancybox_iframe_mm').length) {
				$("a.fancybox_iframe_mm").fancybox({
					type : 'iframe',
					height : '95%',
					width : '90%',
					afterLoad : function(upcoming) {
						$($('iframe[id^=fancybox]')).attr('scrolling', 'yes');
					},
					beforeClose : function() {
						var iframe = $("iframe.fancybox-iframe").get(0);
						if (iframe.contentWindow) {
							iframe.contentWindow.Joomla.submitbutton('module.cancel');
						} else if (iframe.contentDocument) {
							iframe.contentDocument.Joomla.submitbutton('module.cancel');
						}
					}
				});
			};

			$('#fancy_closer').on('click', function() {
				parent.jQuery.fancybox.close();
			});
		};

		/**
		 * Function dummy constructor
		 * 
		 * @access private
		 * @method <<IIFE>>
		 * @return Void
		 */
		(function __construct() {
			// Add preview button using fancybox iframe
			addPreviewButton();

			// Add modules manager button
			addMMButton();
		}).call(this);
	}

	// On DOM Ready
	$(function() {
		var ResponsivizerModulesManagerDrag = new ModulesManagerDrag();
	});
})(jQuery);