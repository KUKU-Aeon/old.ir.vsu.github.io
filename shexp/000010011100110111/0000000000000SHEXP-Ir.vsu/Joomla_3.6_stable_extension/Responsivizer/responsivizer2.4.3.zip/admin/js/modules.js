/**
* Main APP for the interactive interface
* 
* @package RESPONSIVIZER::components::com_responsivizer
* @subpackage js 
* @author Joomla! Extensions Store
* @copyright (C) 2015 Joomla! Extensions Store
* @license GNU/GPLv2 or later, see license.txt
*/
//'use strict';
window.addEvent("domready", function() {
	var b = true;
	
	// Store original dragged element position
	var rsTargetPosition = {};
	
	// Store target element position
	var rsTargetDimensions = {};
	
	// Store original dragged element dimensions
	var rsOriginalDimensions = {};
	
	// Fallback new module clicked element to drag and add IE 11 fix
	var fallbackNewDragModule = null;
	
	// Polyfill for date now
	if (!Date.now) {
	    Date.now = function() { return new Date().getTime(); }
	}
	function getTime() {
		return Math.floor(Date.now() / 1000);		
	}
	
	// Start new class additional taskss merged
	function reorderModuleRequest(orderingData) {
		var options = this.options;
		// Build the query string
		var queryString = '';
		orderingData.each(function(index, value){
			queryString += 'cid[]=' + index + '&order[]=' + parseInt(value+1) + '&';
		});
		var ajaxEndpoint = rvzrBaseURI + "index.php?option=com_responsivizer&task=modules.saveorder&tmpl=component&time=" + getTime();
		var f = new Request({
			url : ajaxEndpoint,
			async : true,
			data : queryString.substring(0, queryString.length - 1),
			onComplete : function(response) {}
		}).send();
	}
	
	var rsDropper = new Class({
		options : {
			dropables : null
		},
		initialize : function() {
			this.getDropable();
			var d = $$(".rs_move_icon");
			this.dragExistingMod(d)
		},
		getDropable : function() {
			var d = $$(".rs-position-name");
			this.options.dropables = d;
			return
		},
		dragExistingMod : function(d) {
			var bindContext = this;
			var e = this.options;
			d.addEvent("mousedown", function(i) {
				var h = this.getParent();
				var j = h.getParent().getChildren()[0];
				var f = h.getCoordinates();
				var k = h.clone().setStyles(h.getCoordinates()).setStyles({
					opacity : 0.9,
					position : "absolute",
					'box-sizing' : 'border-box'
				}).set("id", h.get("id")).inject(document.body);
				h.setStyles({
					opacity : 0
				});
				var g = new Drag.Move(k, {
					droppables : e.dropables,
					onStart : function(element, event) {
						$$('.rs-position-name').addClass('rs-armed_targets');
					},
					onDrop : function(l, n) {
						if (!n) {
							l.destroy();
							$$('.rs-position-name').removeClass('rs-armed_targets');
							$$('.rs-position-name').removeClass('rs-enter_targets');
						} else {
							if (j == n) {
								l.destroy();
								return
							}
							
							var j = n.get("text");
							var i = false;
							
							var nextElem = n.getNext('div');
							l.inject(nextElem);
							
							h.replaces(l);
							l.destroy()
							
							$$('.rs-position-name').removeClass('rs-armed_targets');
							$$('.rs-position-name').removeClass('rs-enter_targets');
							
							// Store the request
							var f = new Request({
								url : rvzrBaseURI + "index.php?option=com_responsivizer&task=module.drop&mid=" + l.get("id") + "&position=" + j + "&tmpl=component&time=" + getTime(),
								async : true
							}).send();
						}
						
						// Append or prepend
						if(rsAddToTop && n){
							var cloneH = h.clone(true, true);
							var nextContainer = n.getNext();
							cloneH.inject(nextContainer, 'top');
							h.destroy();
							cloneH.setStyles({
								opacity : 1,
								height : 'auto'
							});
							bindContext.dragExistingMod(cloneH.getElement('.rs_move_icon'));
						} else {
							h.setStyles({
								opacity : 1,
								height : 'auto'
							})
						}
						rsTargetPosition = {};
					},
					onEnter : function(m, l) {
						rsOriginalDimensions = m.getSize();
						
						m.addClass('rs-entered_targets');
						l.addClass('rs-enter_targets');
						rsTargetDimensions = l.getSize();
						rsTargetPosition = l.getPosition();
						k.setStyles ({
							width : rsTargetDimensions.x,
							left : rsTargetPosition.x
						});
					},
					onDrag : function (element, event) {
						if(rsTargetPosition.x) {
							element.setStyles ({
								left : parseInt(event.client.x - rsTargetDimensions.x)
							});
						}
					},
					onLeave : function(m, l) {
						m.removeClass('rs-entered_targets');
						l.removeClass('rs-enter_targets');
						k.setStyles ({
							width : rsOriginalDimensions.x,
							left : 'auto'
						});
						rsTargetPosition = {};
					},
					onCancel : function(l) {
						$$('.rs-position-name').removeClass('rs-armed_targets');
						$$('.rs-position-name').removeClass('rs-enter_targets');
						l.destroy()
						h.setStyles({
							opacity : 1,
							height : 'auto'
						});
						rsTargetPosition = {};
					}
				});
				g.start(i)
				
				var sortableID = h.getParent().get('id');
				var sb = new Sortables(sortableID, {
					// set options 
					clone:false,
					revert: true,
					constraint: true,
					// initialization stuff here
					initialize: function() { 
						
					},
					onStart: function(el) { 
						el.setStyles({
							opacity : 0
						});
						sb.attach();
					},
					// when a drag is complete 
					onComplete: function(el) {
						el = $(el.getAttribute('id'));
						$$('.rs-position-name').removeClass('rs-armed_targets');
						el.setStyles({
							opacity : 1
						});
						var elementsToSerialize = el.getParent().getChildren();
						var indexesOrdering = new Array();
						elementsToSerialize.each(function(element, index){
							var elementID = element.getAttribute('id');
							indexesOrdering[index] = elementID;
						});
						reorderModuleRequest.call(bindContext, indexesOrdering);
						sb.detach();
					}
				});
			})
		}
	});

	$$('a .rsicon-lock').addEvent("click", function(f) {
		f.stop();
		var positionTrigger = f.client.y;
		var target = this.getParent().getAttribute('href');
		SqueezeBox.open(target, {
			handler : "iframe",
			iframePreload : false,
			closable: false,
			closeBtn: false,
			ajaxOptions : {
				method : "post"
			},
			onOpen : function() {
				$('sbox-window').hide();
				setTimeout(function(){
					window.location.reload(true);
				},500);
			}
		})
	});
	
	var b = new rsDropper()
});

// Reappend correct query string params to page href links to propagate
jQuery(function($) {
	var queryString = window.location.search;
	queryString = queryString.replace("?", ''); // remove the ?
	$('a').each(function(index, element){
		// Initial state
		var currentHRef = $(element).attr('href');
		if(currentHRef && currentHRef != '#') {
			// Found query string
			if(currentHRef.match(/\?/gi)) {
				currentHRef += '&' + queryString;
			} else {
				// No query string found in URL
				currentHRef += '?' + queryString;
			}
			// New state
			$(element).attr('href', currentHRef);
		}
	});
})