DROP TABLE IF EXISTS `#__rvzr_offline_urls`;
DROP TABLE IF EXISTS `#__rvzr_modules`;