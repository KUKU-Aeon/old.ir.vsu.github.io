<?php
// namespace administrator\components\com_responsivizer\tables;
/**
 *
 * @package RESPONSIVIZER::REDIRECTS::administrator::components::com_responsivizer
 * @subpackage tables
 * @author Joomla! Extensions Store
 * @copyright (C)2015 - Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html
 */
// no direct access
defined ( '_JEXEC' ) or die ( 'Restricted access' );

/**
 * ORM Table for offline cache pages
 *
 * @package RESPONSIVIZER::REDIRECTS::administrator::components::com_responsivizer
 * @subpackage tables
 * @since 2.0
 */
class TableRedirects extends JTable {
	/**
	 * @var int
	 */
	public $id = null;
	
	/**
	 * @var int
	 */
	public $itemid_source = null;
	
	/**
	 * @var string
	 */
	public $itemid_target = null;
	
	/**
	 * @var int
	 */
	public $checked_out = 0;
	
	/**
	 * @var datetime
	 */
	public $checked_out_time = 0;
	
	/**
	 * @var int
	 */
	public $published = 1;
	
	/**
	 * @var string
	 */
	public $description = null;
	
	
	/**
	 * Class constructor
	 * @param Object& $_db
	 * 
	 * return Object&
	 */
	public function __construct(&$_db) {
		parent::__construct ( '#__rvzr_redirects', 'id', $_db );
	}
}