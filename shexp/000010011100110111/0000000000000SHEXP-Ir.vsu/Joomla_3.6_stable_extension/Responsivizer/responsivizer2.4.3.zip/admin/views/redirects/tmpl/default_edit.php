<?php 
/** 
 * @package RESPONSIVIZER::REDIRECTS::administrator::components::com_responsivizer
 * @subpackage views
 * @subpackage sources
 * @subpackage tmpl
 * @author Joomla! Extensions Store
 * @copyright (C)2015 - Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html  
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' ); 
?>
<form action="index.php" method="post" name="adminForm" id="adminForm"> 
	<div class="accordion-group">
    	<div class="accordion-heading opened">
	    	<div class="accordion-toggle noaccordion">
	      		<h4><?php echo JText::_( 'COM_RESPONSIVIZER_REDIRECT_DETAILS' ); ?></h4>
	    	</div>
    	</div>
    	<div id="collapseOne" class="accordion-body collapse in">
	      	<div class="accordion-inner">
	        	<table class="admintable">
					<tbody>
						<tr>
							<td class="left_title float10">
								<label class="label label-info" for="title">
									<?php echo JText::_( 'COM_RESPONSIVIZER_SOURCE_TITLE_LABEL' ); ?>:
								</label>
							</td>
							<td class="right_details float30">
								<?php echo $this->lists['itemid_source']; ?>
							</td>
							
							<td class="key float10 redirects_arrow" style="position:relative">
								<label class="label label-info" for="title">
									<?php echo JText::_( 'COM_RESPONSIVIZER_TARGET_TITLE_LABEL' ); ?>:
								</label>
							</td>
							<td class="right_details float30">
								<?php echo $this->lists['itemid_target']; ?>
							</td>
						</tr>
						
						<tr>
							<td class="key left_title float10">
								<label for="type">
									<?php echo JText::_( 'COM_RESPONSIVIZER_DESCRIPTION' ); ?>:
								</label>
							</td>
							<td class="right_details" colspan="100%">
								<textarea class="inputbox" type="text" name="description" id="description" rows="5" cols="80"><?php echo $this->record->description;?></textarea>
							</td>
						</tr> 
						<tr>
							<td class="key left_title float10">
								<label for="description">
									<?php echo JText::_( 'COM_RESPONSIVIZER_PUBLISHED' ); ?>:
								</label>
							</td>
							<td class="right_details" colspan="100%">
								<fieldset class="radio btn-group small">
									<?php echo $this->lists['published']; ?>
								</fieldset>
							</td>
						</tr> 
						
					</tbody>
				</table>
	  		</div>
	    </div>
  	</div>

	<input type="hidden" name="option" value="<?php echo $this->option?>" />
	<input type="hidden" name="id" value="<?php echo $this->record->id; ?>" />
	<input type="hidden" name="task" value="" />
</form>