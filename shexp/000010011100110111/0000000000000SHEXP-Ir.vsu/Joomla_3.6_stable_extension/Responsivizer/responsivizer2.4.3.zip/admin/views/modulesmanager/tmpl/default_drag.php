<?php 
/** 
 * @package RESPONSIVIZER::MODULESMANAGER::administrator::components::com_responsivizer
 * @subpackage views
 * @subpackage modulesmanager
 * @subpackage tmpl
 * @author Joomla! Extensions Store
 * @copyright (C) 2015 - Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html  
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' ); 
?>
<form action="index.php" method="post" name="adminForm" id="adminForm" class="copy"> 
	<div class="label label-primary"><?php echo JText::_('COM_RESPONSIVIZER_DRAGAREA_HOWTO');?></div>
	<div class="drag_size_labels">
		<span class="label label-info positions"><?php echo JText::sprintf('COM_RESPONSIVIZER_DRAGAREA_SIZE_WIDTH', $this->iFrameWidth);?></span>
		<span class="label label-info positions"><?php echo JText::sprintf('COM_RESPONSIVIZER_DRAGAREA_SIZE_HEIGHT', $this->iFrameHeight);?></span>
	</div>
	
	<div id="modules_panel">
		<div class="well dragmodules">
			<iframe id="rvzr_dragmodules" src="<?php echo JUri::root();?>?rsenable=1&amp;template=<?php echo $this->mobileTemplate;?>&amp;token=<?php echo $this->token;?>"></iframe>
			<div id="iphone_btn"></div>
		</div>
	</div>
	
	<input type="hidden" name="option" value="<?php echo $this->option?>" />
	<input type="hidden" name="task" value="cpanel.display" />
</form>