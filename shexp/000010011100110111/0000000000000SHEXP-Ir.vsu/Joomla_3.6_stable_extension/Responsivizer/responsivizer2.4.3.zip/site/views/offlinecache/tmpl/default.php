<?php
/** 
 * @package RESPONSIVIZER::OFFLINECACHE::components::com_responsivizer
 * @subpackage views
 * @subpackage offlinecache
 * @subpackage tmpl
 * @author Joomla! Extensions Store
 * @copyright (C)2015 - Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html
 */
defined('_JEXEC') or die('Restricted access');
?>