<?php
/** 
 * @package RESPONSIVIZER::components::com_responsivizer 
 * @subpackage controllers
 * @author Joomla! Extensions Store
 * @copyright (C)2015 Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html  
 */
defined ( '_JEXEC' ) or die ();

jimport ( 'joomla.application.component.controller' );
jimport ( 'joomla.application.component.controllerform' );

/**
 * Main controller class
 * 
 * @package RESPONSIVIZER::components::com_responsivizer
 * @subpackage controllers
 * @since 1.0
 */
class ResponsivizerControllerModule extends JControllerForm {
	/**
	 * Check ACL permissions
	 * 
	 * @access public
	 * @return boolean
	 */
	protected function allowAdd($data = array()) {
		return true;
	}
	
	/**
	 * Check ACL permissions
	 *
	 * @access public
	 * @return boolean
	 */
	protected function allowEdit($data = array(), $key = 'id') {
		return true;
	}
	
	/**
	 * Check ACL permissions
	 *
	 * @access public
	 * @return boolean
	 */
	protected function allowSave($data, $key = 'id') {
		return true;
	}
	
	/**
	 * Reorder drop move entity
	 *
	 * @access public
	 * @return boolean
	 */
	public function drop() {
		$app = JFactory::getApplication ();
			
		$mid = $app->input->get ( 'mid', 0, 'int' );
		$position = $app->input->get ( 'position', 'null', 'string' );
		$model = $this->getModel ( 'module' );
		$assigned = $model->getModuleAssignments ( $mid );
		$assignment = ($assigned [0] > 0) ? 1 : - 1;
		
		// set ordering at the last
		$data = array (
				'id' => $mid,
				'position' => $position,
				'assignment' => $assignment,
				'assigned' => $assigned 
		);
		if ($model->save ( $data )) {
			$output = 1;
		} 
		// Output the JSON data.
		echo json_encode ( $output );
		
		jexit ();
	}
	
}