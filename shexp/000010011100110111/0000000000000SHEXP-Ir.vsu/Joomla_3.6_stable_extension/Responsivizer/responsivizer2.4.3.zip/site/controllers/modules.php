<?php
/** 
 * @package RESPONSIVIZER::components::com_responsivizer 
 * @subpackage controllers
 * @author Joomla! Extensions Store
 * @copyright (C)2015 Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html  
 */
defined ( '_JEXEC' ) or die ();

/**
 * Dummy used controller for modules admin tasks
 * 
 * @package RESPONSIVIZER::components::com_responsivizer
 * @subpackage controllers
 */
class ResponsivizerControllerModules extends JControllerAdmin {
	/**
	 * Method to save the submitted ordering values for records.
	 *
	 * @return boolean True on success
	 *        
	 * @since 1.0
	 */
	public function saveorder() {
		// Get the input
		$pks = $this->input->post->get ( 'cid', array (), 'array' );
		$order = $this->input->post->get ( 'order', array (), 'array' );
		
		// Sanitize the input
		JArrayHelper::toInteger ( $pks );
		JArrayHelper::toInteger ( $order );
		
		// Get the model
		$model = $this->getModel ();
		
		// Save the ordering
		$return = $model->saveorder ( $pks, $order );
		
		echo $return;
		exit();
	}
	
	/**
	 * Method to get a model object, loading it if required.
	 *
	 * @param string $name
	 *        	The model name. Optional.
	 * @param string $prefix
	 *        	The class prefix. Optional.
	 * @param array $config
	 *        	Configuration array for model. Optional.
	 *        	
	 * @return object The model.
	 *        
	 * @since 1.0
	 */
	public function getModel($name = 'Module', $prefix = 'ResponsivizerModel', $config = array('ignore_request' => true)) {
		$model = parent::getModel ( $name, $prefix, $config );
		return $model;
	}
}
