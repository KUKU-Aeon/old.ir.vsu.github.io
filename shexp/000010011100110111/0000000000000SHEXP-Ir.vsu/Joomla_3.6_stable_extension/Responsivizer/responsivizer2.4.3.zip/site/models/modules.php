<?php
/** 
 * @package RESPONSIVIZER::components::com_responsivizer 
 * @subpackage models
 * @author Joomla! Extensions Store
 * @copyright (C)2015 Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html  
 */
defined ( '_JEXEC' ) or die ();

jimport ( 'joomla.application.component.modellist' );

/**
 *
 * @package RESPONSIVIZER::components::com_responsivizer
 * @subpackage models
 * @since 1.0
 */
class ResponsivizerModelModules extends JModelList {
}