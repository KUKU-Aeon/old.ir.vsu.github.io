<?php
// namespace components\com_responsivizer\models;
/**
 * @package RESPONSIVIZER::DYNAMICCSS::components::com_responsivizer
 * @subpackage models
 * @author Joomla! Extensions Store
 * @copyright (C)2015 - Joomla! Extensions Store
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

/**
 * Main offline cache resources model class
 *
 * @package RESPONSIVIZER::DYNAMICCSS::components::com_responsivizer
 * @subpackage models
 * @since 2.1
 */
class ResponsivizerModelDynamiccss extends ResponsivizerModel {  

}