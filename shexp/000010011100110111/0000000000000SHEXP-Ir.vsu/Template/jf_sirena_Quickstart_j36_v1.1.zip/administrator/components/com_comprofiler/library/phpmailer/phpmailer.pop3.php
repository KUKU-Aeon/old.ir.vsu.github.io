<?php
/**
 * CB, Community Builder (TM)
 * @version $Id: 6/16/14 6:37 PM $
 * @copyright (C) 2004-2016 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
 */

/**
 * Old Class CBPOP3
 * @deprecated 2.0
 */
class CBPOP3 extends \CBPHPMailer\CBPOP3
{
}
