<?php

// ensure this file is being included by a parent file
if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

/**
 * The classes CBSnoopy and Snoopy that were in here have moved to libraries/CBLib/CB/Legacy folder.
 */
