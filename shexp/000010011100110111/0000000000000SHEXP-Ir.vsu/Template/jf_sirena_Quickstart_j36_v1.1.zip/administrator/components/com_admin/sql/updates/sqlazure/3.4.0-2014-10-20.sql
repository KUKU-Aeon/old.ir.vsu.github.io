DELETE FROM [#__extensions] WHERE [extension_id] = 100;
