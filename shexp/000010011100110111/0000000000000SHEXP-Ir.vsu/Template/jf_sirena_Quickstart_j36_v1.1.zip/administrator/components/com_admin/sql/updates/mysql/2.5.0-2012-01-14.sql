ALTER TABLE `#__languages` CHANGE `sitename` `sitename` VARCHAR( 1024 ) NOT NULL DEFAULT '';

